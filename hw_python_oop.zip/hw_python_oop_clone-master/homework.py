import datetime as dt


class Calculator:
    pass


class Record:
    pass


class CaloriesCalculator(Calculator):
    pass


class CashCalculator(Calculator):
    pass